// Render published, unchanged AQUORA 0.6.10 WASM to real RGB565 LCD captures.
import fs from 'node:fs';
import crypto from 'node:crypto';
const wasm=fs.readFileSync('out/emu/app-0.6.10-50374bf17507.wasm');
const sha=crypto.createHash('sha256').update(wasm).digest('hex');
if(sha!=='50374bf175072373dd3dbe38e30416649bfe19d4d5eb7d4beb10053c5d9740cc')throw Error('Unaccepted WASM');
const dir='out/assets/screens-0610';fs.mkdirSync(dir,{recursive:true});
const manifest=[];
async function device(){
 let ex;
 const wasi=new Proxy({clock_time_get:(_id,_prec,p)=>{new DataView(ex.memory.buffer).setBigUint64(p,0n,true);return 0;},fd_write:(_f,_v,_n,p)=>{new DataView(ex.memory.buffer).setUint32(p,0,true);return 0;}},{get:(t,k)=>t[k]||(()=>0)});
 const {instance}=await WebAssembly.instantiate(wasm,{wasi_snapshot_preview1:wasi,env:new Proxy({},{get:()=>()=>0})});
 ex=instance.exports;ex._initialize?.();ex.web_master(2400);ex.web_boot();
 const wait=ms=>{for(let n=0;n<Math.ceil(ms*44.1/128);n++)ex.web_render(128);};
 const tap=b=>{ex.web_buttons(1<<b);wait(40);ex.web_buttons(0);wait(80);};
 const turn=(r,n)=>{for(let i=0;i<Math.abs(n);i++){ex.web_enc(r,Math.sign(n));wait(130);}};
 const shot=name=>{const b=Buffer.from(new Uint8Array(ex.memory.buffer,ex.web_fb(),240*240*2));fs.writeFileSync(`${dir}/${name}.rgb565`,b);};
 return {ex,wait,tap,turn,shot};
}
const pages={play:0,sound:1,evolve:2,mixer:3,drums:4,appearance:5,air:6,learn:2,'music-mode':2,'mix-strip':3};
for(const [name,page] of Object.entries(pages)){
 const d=await device();d.wait(9000);d.tap(6);d.turn(1,page);
 if(name==='learn'||name==='music-mode'){for(let n=0;n<(name==='learn'?5:4);n++)d.tap(4);if(name==='music-mode')d.turn(3,3);}
 if(name==='air')d.tap(4);
 if(name==='appearance')d.turn(0,1);
 if(name==='mix-strip')d.tap(0);
 d.wait(2000);d.shot(name);manifest.push({file:`${name}.png`,page,renderer:'accepted published WASM LCD',wasm_sha256:sha});
}
for(let mode=0;mode<3;mode++){
 const name=['original','cymatics','chladni'][mode],d=await device();d.wait(9000);d.tap(6);d.turn(1,5);d.turn(0,1);d.turn(6,mode);d.tap(6);d.wait(11000);
 for(let f=0;f<24;f++){d.wait(100);d.shot(`${name}-${String(f).padStart(2,'0')}`);}
 manifest.push({file:`${name}.png`,animation:`${name}.apng`,frames:24,interval_ms:100,renderer:'accepted published WASM LCD, playing, idle fullscreen',wasm_sha256:sha});
}
const intro=await device();intro.wait(5000);intro.shot('intro');manifest.push({file:'intro.png',renderer:'accepted published WASM startup LCD',wasm_sha256:sha});
fs.writeFileSync(`${dir}/provenance.json`,JSON.stringify({version:'0.6.10',firmware_source:'654d725ed98361bca3df9f477b9a5989d299d0a4',captures:manifest},null,2)+'\n');
console.log(`Captured ${manifest.length} scenes from accepted WASM; no compilation.`);
