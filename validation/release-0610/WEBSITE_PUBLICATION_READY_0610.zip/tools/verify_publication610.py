"""Publication checks for changed website pages, actual images and protected artifacts."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse,unquote
from PIL import Image
import json,hashlib,re
root=Path('out').resolve();fail=[];refs=[]
class Links(HTMLParser):
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  for a in ['href','src','data-animated']:
   if a in d:refs.append((self.path,d[a]))
for f in root.rglob('*.html'):
 parser=Links();parser.path=f;parser.feed(f.read_text())
for f,u in refs:
 p=urlparse(u)
 if p.scheme or p.netloc or not p.path:continue
 target=(root/p.path.lstrip('/') if p.path.startswith('/') else f.parent/p.path).resolve()
 if target.is_dir():target=target/'index.html'
 if not target.exists():fail.append((str(f.relative_to(root)),u))
assert not fail,fail
for key,expected in {
 'firmware/sound-healing-0.6.10.fwsc':'e31fc01b728b51e6e7ea25fc8ae389fcb35a7fb201071aed12502d4098833378',
 'emu/app-0.6.10-50374bf17507.wasm':'50374bf175072373dd3dbe38e30416649bfe19d4d5eb7d4beb10053c5d9740cc',
 'emu/worklet-0.6.10-b9c31b07473e.js':'b9c31b07473e2f0aeca957b74627ae23f1c42ed5132a26c124cd54e5ba2fa9f7',
 'downloads/0.6.10/AQUORA-0.6.10-installer.zip':'633a50e0e710e7a69fe4120531643ee94e63ffd08cf3af7df7a636941f9155d4',
 'firmware/sound-healing-0.6.7.fwsc':'5dcd602134b37c6b81e982aea9998086360dc4e665664dc6dbfbb0ba60c6c83a',
 'firmware/sound-healing-0.6.8.fwsc':'86527d3167c125ee3e9e433b3663f335f102e98b53bb89e00e1fd5091c15a525',
}.items():assert hashlib.sha256((root/key).read_bytes()).hexdigest()==expected,key
for f in (root/'assets/screens-0610').glob('*.png'):
 with Image.open(f) as im:assert im.size==(240,240),f
for f in (root/'assets/screens-0610').glob('*.apng'):
 with Image.open(f) as im:assert im.n_frames==24 and im.size==(240,240),f
for name in ['index.html','screens/index.html','manual/index.html','studio/index.html','emu/index.html','downloads/index.html','release/index.html','install/index.html']:
 text=(root/name).read_text();assert '0.6.10' in text
 assert not re.search(r'(?:assets/[^"\s]*-06[678]\.(?:png|apng)|86 indexed|95 searchable|Three musical languages|Playback starts on PLAY)',text),name
assert max(f.stat().st_size for f in root.rglob('*') if f.is_file())<=26214400
print(f'PASS {len(refs)} internal/external references inventoried; all local destinations exist;14 current240px screens, three24-frame animations; firmware/WASM/worklet/ZIP/067+068 hashes unchanged; hosting size gate passed')
