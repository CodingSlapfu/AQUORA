from pathlib import Path
import zipfile,json,hashlib,re,shutil
O=Path('out');R=Path('/workspace/scratch/1b74ec6feab1/release610');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Stage exact committed release bytes; this is not a firmware build/test.
for line in (R/'SHA256SUMS.txt').read_text().splitlines():
 h,n=line.split(None,1);assert sha(R/n.strip())==h
rollback=O/'rollback/0.6.9';rollback.mkdir(parents=True,exist_ok=True)
shutil.copytree(O/'install',rollback/'install',dirs_exist_ok=True);shutil.copytree(O/'firmware',rollback/'firmware',dirs_exist_ok=True)
oldemu=(O/'emu/index.html').read_text();bridge=oldemu[oldemu.index('// ---------------------------------------------------------------- AQUORA Studio companion bridge (site-only)'):oldemu.rfind('</script>')]
D=O/'downloads/0.6.10';D.mkdir(parents=True,exist_ok=True)
for f in R.iterdir():shutil.copy2(f,D/f.name)
fw=R/'sound-healing-0.6.10.fwsc';shutil.copy2(fw,O/'firmware'/fw.name)
with zipfile.ZipFile(R/'AQUORA-0.6.10-emulator.zip') as z:
 html=z.read('index.html').decode();worklet=z.read('worklet.js');wasm=z.read('app.wasm')
wh=hashlib.sha256(wasm).hexdigest();jh=hashlib.sha256(worklet).hexdigest();assert wh=='50374bf175072373dd3dbe38e30416649bfe19d4d5eb7d4beb10053c5d9740cc'
wn=f'app-0.6.10-{wh[:12]}.wasm';jn=f'worklet-0.6.10-{jh[:12]}.js'
(O/'emu'/wn).write_bytes(wasm);(O/'emu'/jn).write_bytes(worklet)
html=html.replace('fetch("app.wasm")',f'fetch("{wn}")').replace('addModule("worklet.js")',f'addModule("{jn}")').replace('<title>sound-healing in the browser</title>','<title>AQUORA 0.6.10 — FM-1 Browser Emulator</title>')
html=re.sub(r'<h1>.*?</h1>','<h1>AQUORA <small>0.6.10</small></h1>',html,count=1,flags=re.S)
html=html.replace('</script>',bridge+'\n</script>',1)
nav='<nav aria-label="AQUORA navigation" style="max-width:1040px;margin:16px auto;padding:0 16px;font:14px/1.8 system-ui"><a href="/">AQUORA 0.6.10</a> · <a href="/studio/">Studio</a> · <a href="/manual/">Guide</a> · <a href="/downloads/">Downloads & rollback</a></nav>'
html=html.replace('<body>','<body>'+nav,1);(O/'emu/index.html').write_text(html)
with zipfile.ZipFile(R/'AQUORA-0.6.10-installer.zip') as z:s=z.read('install/index.html').decode()
s=s.replace('<main>',nav+'<main>',1);(O/'install/index.html').write_text(s)
# Current page text/media references only; all historical archives remain untouched.
for n in ['index.html','screens/index.html','studio/index.html','manual/index.html','downloads/index.html','release/index.html','backup/index.html','screen-carousel.js']:
 p=O/n;s=p.read_text().replace('0.6.9','0.6.10').replace('screens-069','screens-0610').replace('32-step follow-playhead','32-step follow-playhead').replace('sixteen song sections','32 song sections').replace('sixteen sections','32 sections').replace('sixteen evolving sections','32 evolving sections').replace('Sixteen','Thirty-two').replace('Sixteen','Thirty-two');p.write_text(s)
# Update current feature descriptions while keeping every existing Studio control/bridge.
p=O/'index.html';s=p.read_text().replace('Eight roles develop through sixteen sections.','Eight roles develop through 32 section functions, with prepared transitions and retained musical anchors.').replace('16/32/64-step loops, sixteen song sections','16/32/64-step loops, 32 section functions');s=s.replace('CURRENT RELEASE / AQUORA v0.6.10','CURRENT RELEASE / AQUORA v0.6.10');s=s.replace('After the original startup signature, v0.6.10 begins a fresh randomized arrangement. PLAY stops it.','Fresh intention-aware tempos, 32 section functions and musical transitions. After the intro, a randomized arrangement begins; PLAY stops it.');p.write_text(s)
# Publish current guide with accepted release changes; previous guide stays archived.
g=(O/'manual/GUIDE-0.6.9.md').read_text().replace('0.6.9','0.6.10').replace('sixteen song sections','32 section functions')
changes=(R/'RELEASE.md').read_text();g=g.replace('## Start and stop','## Changes in v0.6.10\n\n'+changes.split('Compatibility:')[0].split('\n\n',2)[2]+'\n\n## Start and stop',1)
(O/'manual/GUIDE-0.6.10.md').write_text(g)
p=O/'manual/index.html';s=p.read_text().replace('sixteen song sections','32 section functions');insert='<section class="guide-section"><h2>New in v0.6.10</h2><p>New songs select intention/mode-aware tempos. The arranger uses 32 section functions with prepared transitions, retained anchors and current-kit fills. EVOLVE now shows eight activity lanes, larger events, a 32-step follow-playhead viewport and a 64-step miniature overview. Manual tempo and drum presence persist. Original keeps its geometry; Cymatics and Chladni have stronger music-driven motion.</p></section>';s=s.replace('<nav class="guide-toc"',insert+'<nav class="guide-toc"',1);p.write_text(s)
p=O/'release/index.html';s=p.read_text();s=s.replace('<h2>What changed in v0.6.10</h2>','<h2>What changed in v0.6.10</h2><p>New songs choose varied intention/mode-aware tempos; manual tempo and drum presence persist. The continuous arranger adds 32 section functions, prepared role transitions, retained anchors and pickups. EVOLVE gains eight activity lanes with larger events, a 32-step viewport and miniature overview. Original, Cymatics and Chladni retain their identity with improved musical response.</p><h2>Retained from v0.6.9</h2>');s=s.replace('Website refresh','Current website');p.write_text(s)
p=O/'downloads/index.html';s=p.read_text();s=s.replace('Identity FM-1_73000609','Identity FM-1_73000610');s=re.sub(r'<p>.*?The exact accepted source archive is split.*?</p>', '<p><a href="https://github.com/CodingSlapfu/AQUORA/tree/aquora-next-integration">Verified source and release backups</a>. Download the complete source archive and verify it using the release checksums.</p>',s,count=1,flags=re.S) if False else s
s=s.replace('The exact accepted source archive is split into host-sized parts. Download all parts and concatenate in numeric order; use the manifest to verify each part and the complete archive.','The complete accepted v0.6.10 source archive fits in one file. Verify it against the release checksums.')
s=re.sub(r'<li><a href="0.6.10/AQUORA-0.6.10-source.tar.gz.part\d+">Source part \d of 3</a></li>','',s)
s=s.replace('<a href="0.6.10/SOURCE-MANIFEST.json">v0.6.10 source manifest</a>','<a href="0.6.10/SOURCE-MANIFEST.json">v0.6.10 source manifest</a></li><li><a href="0.6.10/AQUORA-0.6.10-complete-source.tar.gz">Complete source archive</a></li><li><a href="0.6.10/SHA256SUMS.txt">Release checksums</a>')
s=s.replace('<ul><li><a href="/rollback/0.6.8/install/">','<ul><li><a href="/rollback/0.6.9/install/">v0.6.9 rollback installer</a> · <a href="/firmware/sound-healing-0.6.9.fwsc">firmware</a></li><li><a href="/rollback/0.6.8/install/">',1);p.write_text(s)
# Link all rollback installers from current installer; no update-protocol edits.
p=O/'install/index.html';s=p.read_text();s=s.replace('</main>','<p><a href="/rollback/0.6.9/install/">Preserved v0.6.9 rollback installer</a> · <a href="/downloads/">All downloads and rollback</a></p></main>',1);p.write_text(s)
# Paired accepted audio evidence, copied without regeneration.
L=O/'listening/0.6.10';L.mkdir(parents=True,exist_ok=True);a=Path('/workspace/scratch/9e3e15408fe4/acceptance610/listening');sections=''
for name in ['warm-pulse','slow-drift','interlocking-lights','quiet-broken-orbit','chamber-answer','experimental-orbit']:
 for version in ['069','0610']:shutil.copy2(a/f'{name}-{version}.ogg',L/f'{name}-{version}.ogg')
 sections+=f'<section><h2>{name.replace("-"," ").title()}</h2><p>Accepted original-DSP, 180-second level-matched comparison; no invented listening approval.</p><label>v0.6.9 <audio controls preload="none" src="{name}-069.ogg"></audio></label><label>v0.6.10 <audio controls preload="none" src="{name}-0610.ogg"></audio></label></section>'
(L/'index.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>AQUORA0.6.10 Listening comparisons</title><link rel="stylesheet" href="/style.css"><body>'+nav+'<main class="container reading"><h1>AQUORA v0.6.10 listening comparisons</h1>'+sections+'</main></body></html>')
r=json.loads((O/'release.json').read_text());r.update(version='0.6.10',identity='FM-1_73000610',source_commit='654d725ed98361bca3df9f477b9a5989d299d0a4',software_acceptance='passed',hardware_acceptance='owner-unverified')
r['firmware']={'url':'firmware/'+fw.name,'bytes':fw.stat().st_size,'sha256':sha(fw)};r['wasm']={'url':'emu/'+wn,'bytes':len(wasm),'sha256':wh};r['worklet']={'url':'emu/'+jn,'sha256':jh};r['installer_zip']={'url':'downloads/0.6.10/AQUORA-0.6.10-installer.zip','sha256':sha(R/'AQUORA-0.6.10-installer.zip')};r['source_archive_sha256']=sha(R/'AQUORA-0.6.10-complete-source.tar.gz');r['rollback']['0.6.9']=sha(O/'firmware/sound-healing-0.6.9.fwsc');r['compatibility']['warning']=r['compatibility']['warning'].replace('0.6.9','0.6.10');r['release_notes']='downloads/0.6.10/RELEASE.md';r['website_refresh']={'version':'0.6.10','screens':'assets/screens-0610/provenance.json','guide':'manual/','downloads':'downloads/','notes':'release/'}
(O/'release.json').write_text(json.dumps(r,indent=2)+'\n')
# Reuse capture-only tooling against accepted WASM, never compiling or regenerating WASM.
s=Path('tools/capture069.mjs').read_text().replace('0.6.9','0.6.10').replace('screens-069','screens-0610').replace('2b79c5b3e55d4982d0f2b7a51bbad6924347dfc6735ed75e393a42b364bc8d6a',wh).replace('app-0.6.10-2b79c5b3e55d.wasm',wn).replace('dc3db77347bdf9abfad1045c5d9b562b99fd1abf','654d725ed98361bca3df9f477b9a5989d299d0a4');Path('tools/capture610.mjs').write_text(s)
s=Path('tools/convert069.py').read_text().replace('screens-069','screens-0610');Path('tools/convert610.py').write_text(s)
print('Staged exact committed610 release; retained069rollback, earlier archives, AIR, Studio bridge and warning. No firmware compilation/tests.')
