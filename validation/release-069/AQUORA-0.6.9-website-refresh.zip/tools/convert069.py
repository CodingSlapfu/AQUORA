"""Decode accepted-WASM panel byte order, matching emu/index.html; no image invention."""
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
p=Path('out/assets/screens-069')
for f in p.glob('*.rgb565'):
 a=np.frombuffer(f.read_bytes(),dtype='>u2').reshape(240,240)
 rgb=np.stack([((a>>11)&31)*255//31,((a>>5)&63)*255//63,(a&31)*255//31],-1).astype('uint8')
 Image.fromarray(rgb).save(f.with_suffix('.png'));f.unlink()
for name in ['original','cymatics','chladni']:
 frames=[Image.open(p/f'{name}-{i:02}.png').convert('RGB') for i in range(24)]
 frames[0].save(p/f'{name}.png')
 frames[0].save(p/f'{name}.apng',format='PNG',save_all=True,append_images=frames[1:],duration=100,loop=0)
 for f in p.glob(name+'-*.png'):f.unlink()
m=json.loads((p/'provenance.json').read_text());m['pixel_format']='panel byte-swapped RGB565, decoded exactly as published emulator'
m['files']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.suffix in ['.png','.apng']}
(p/'provenance.json').write_text(json.dumps(m,indent=2)+'\n')
