# AQUORA 0.6.0 — FM-1

An original generative musical instrument for reflective listening. Patch names describe synthesized instruments.

## Start
Turn the physical master down, install, then press PLAY and raise the master gradually. Playback starts only when requested. PLAY stops new events immediately and fades the entire mix over 256 samples (5.8 ms at 44.1 kHz). Digital silence follows until PLAY restarts. Keys play only while transport is running. Release and press a held key again after restarting.

## Navigation
Turn ALGORITHM to choose a page. HOME returns to PLAY. ARP jumps to DRUMS, OCT− opens arrangement banks, and GLO opens Performance. Use SELECT to focus a track or category. On SOUND, EDIT opens the category picker. Turn SELECT to choose, then press EDIT to open it. Knob assignments and values appear at the bottom of the screen.

| Page or SOUND group | K1 | K2 | K3 | K4 |
|---|---|---|---|---|
| PLAY | Scene | Energy | Fixed tone level | Nature level |
| SOUND / Instrument (pitched) | Patch | Brightness | Attack | Release |
| SOUND / Track Routing | Track level | Pan | FX send | Solo / clear |
| SOUND / Nature | Bed | Bed level | Reverb | Delay |
| SOUND / Frequency | Fixed Hz | Tone level | Reference Layer / Frequency Lock | Hz Source Auto/Manual |
| SOUND / Binaural | Carrier Hz | Difference (0.5 Hz steps) | Binaural level | Enable toggle |
| SOUND / Percussion | Kit | Drum level | Density 0–8 | Enable toggle |
| SOUND / Sacred Bass | Sacred level | Off / musical / reference | Harmonic blend | Fixed tone level |
| SOUND / Lead / Bass Motion | Off / legato / always glide | Glide milliseconds | Vibrato rate in 0.1 Hz steps | Vibrato depth in cents, 0 disables |
| SOUND / Track Routing | Track level | Pan | FX send | Solo / clear |
| SOUND / Percussion HIT | HIT % (0–100) | Drum level | Density 0–8 | Drums ON/OFF |
| SOUND / Visualizer | Original / Resonance | — | — | — |
| SOUND / Arrangement Banks | Bank 1–4 | LOAD / SAVE | Overwrite arm | Visualizer |
| EVOLVE | Motif variation | Freeze toggle | Tempo | Loop steps 16/32/64 |
| MIX / Channels | Track level | Pan | FX send | Mute |
| MIX / Master FX | Reverb | Delay | Auto Gain | Auto Level |

ENV toggles A4 432/440. FX toggles binaural tones. ARP opens Percussion and turns drums on. Enabling restores audible minimums if density, track level or drum level is too low, unmutes track 8, and clears a conflicting solo. K4 counterclockwise turns drums off. OCT+ switches between Percussion and Percussion HIT. SEQ freezes/unfreezes motif replacement. GLO cycles Performance, Callback/Core and Voice Inspector, then returns to the instrument. In Voice Inspector, K1 selects a voice and SEQ stops transport and clears it with the normal fade. LFO toggles Perfect Key on either diagnostics screen and solos the selected track on the instrument. Perfect Key defaults on and maps all 27 keys to ascending notes in the current scene scale. Stopped SAVE stores Perfect Key and both tracks’ motion settings. Legato glide needs an overlapping note on the same track. Always glide uses the last pitch on that track. Glide and vibrato produce brief continuous excursions around or between scale notes. REC forces single-core graphics until reboot. For ON/OFF encoders turn clockwise to enable and counterclockwise to disable. For Solo turn clockwise to solo the selected role and counterclockwise to clear.

## Frequency and stereo
Fixed tones: 174, 285, 396, 417, 528, 639, 741, 852, 963, 111 and 136.1 Hz. Tone level defaults to zero; raise it on Frequency or PLAY. Sacred Bass has its own gain, source and harmonic blend. Musical mode follows a gated Bass voice and releases with it. The voice inspector distinguishes that layer from the continuous reference and fixed-tone options. Reference mode uses an octave-reduced reference frequency independent of the fixed tone level. A4 tuning changes musical notes separately.

Binaural mode defaults OFF. Left = carrier minus half the difference; right = carrier plus half the difference. Example: carrier 220 Hz, difference 6 Hz gives left 217 Hz and right 223 Hz. Use stereo headphones; speakers and mono are not equivalent. Tones bypass shared effects to retain channel separation, then pass through the output limiter/master. Changes glide and enabling fades in. Start at low volume.

## Instruments and arrangement
24 original algorithmic patches cover bass, drones, piano, plucked strings/guitar, flutes, woodwinds, bells, choir, strings and atmospheric pads. Eight scenes vary scale, tempo, density and nature selection. Anti-Curse uses a grounded minor palette with Sacred Earth percussion. Positive Healing uses a major palette with Moonlit Felt percussion. Each changes bass progression, atmosphere and FX. These are artistic listening intentions. Motifs vary at phrase boundaries; Freeze preserves the motif while its arrangement continues. Sixteen bounded voices share seven pitched tracks. Fifteen synthesized percussion kits share the integrated eighth track. Seven procedural nature types avoid streaming/decoding loads.

## Diagnostics and engineering
The first diagnostics screen separates Audio Processing (callback time excluding measured FX) from FX Processing (timed reverb/delay passes). It shows two-second mean, p95 and peak, callback budget use, DMA xruns, CPU percentage, and core status. The second shows total callback mean, p95/p99 and peak, visual time, active voices, worker fault reason and queue drops. Percentiles use 100-microsecond bins. These are real measurements only on the device. Host numbers are not FM-1 benchmarks. Graphics reduce refresh when reported audio load exceeds 60%. Core 1 optionally computes geometry from an isolated snapshot. A 2 ms worker timeout, invalid job or fault retires the worker and recomputes on core 0. At elevated load animation slows before control feedback. Original keeps the existing geometry. Water Cymatics uses six branches and two evolving rings tied to frequency, scene and musical activity. No audio callback waits for it. REC forces single-core mode until reboot. No hardware speedup is claimed. Startup master is zero until ADC input arrives. The per-sample synthesis, FX and output passes run from SRAM; no dynamic allocation or decoding occurs in the renderer.

## Arrangement banks

Stop playback, press OCT− to open Banks, then choose a slot with K1. K2 selects LOAD or SAVE. Press SAVE to perform the shown action. For a slot marked SAVED or INVALID, arm overwrite with K3 before pressing SAVE. Arming clears after an action, a slot change or an action change. K4 chooses the current visualizer. The status line reports empty, saved, loaded or failed.

Banks store instrument assignments and mixer state, scene, motif and generation state, rhythm and HIT, tempo, effects, nature, reference and binaural settings, motion, Perfect Key and visualizer. Loading restores these settings while stopped. Start with PLAY for a fresh downbeat. Live voice, effect history and playback cursor are excluded. Outside the bank page, stopped SAVE still saves motion and Perfect Key.

## Update and recovery
Use Chrome or Edge with Web MIDI and SysEx permission, connect FM-1 by USB, open the installer and select its ports. The installer checks package integrity and follows the firmware/loader/restarted device identity. Keep power connected. The bundled updater path preserves the boot area; interrupted application writes still require recovery and are not dual-bank rollback.

If normal startup fails, hold OCT- while powering on to request the platform rescue path. OCT- and OCT+ held together for five seconds enter update mode on the running platform. These procedures come from the selected platform and remain to be confirmed on your FM-1. Preserve a stock backup and the existing independent recovery archives. Do not install another bootloader merely for this release.

## Current limitations
Four arrangement banks and the separate motion/Perfect Key settings are persistent. Unsaved changes reset on reboot. Keyed notes have an eight-second missed-release guard. A total voice age guard keeps malformed or unexpectedly long voices bounded. No sampler, Bluetooth, mirror, looper or retired-product functionality is included. One nature bed is selected at a time. Physical clock calibration, sound quality, stereo separation, sustained CPU budget, display FPS, controls, direct version-to-version updating and interrupted-update recovery still require hardware testing.

### Sound Source Isolate

In SOUND, use EDIT to reach **Source Isolate**. K1 selects the full mix, a dry
track, Fixed tone, Sacred Bass, Binaural, Nature or Wet FX. Other audio sources
continue running internally, so Wet FX can be heard with its normal inputs.
Existing mute and solo settings still apply. HOME returns to the full mix.
K2 edits the reference Hz and switches to Manual. K3 adjusts the fixed tone
level. K4 selects the Sacred Bass source. Choose Auto on the Frequency page to
follow the intention again. Reference tone is off until its level is raised.

### Loop length and keyboard

EVOLVE K4 selects 16, 32 or 64 steps. During playback the new length applies
at the start of the next full loop. Longer loops keep the same pulse and
derive distinct response phrases from the stored motif.
Press EDIT on PLAY to switch between Play Along and Change Key. For timing controls, open SOUND > Keyboard or choose Play Along in SETUP > Quick Find. K1 changes mode, K2 selects Live, 1/8, 1/16, 1/32 or Auto, K3 sets timing strength, and K4 selects Straight or Intention feel. Auto uses 1/32 at slower tempos and 1/16 otherwise. At 100%, a note waits for the next grid position. Lower strength shortens the wait. Live and 0% play immediately. Intention feel shifts offbeats for pitched instruments other than Bass. SELECT chooses the Play Along instrument. In Change Key, the keys map chromatically from F
and select the new tonic without sounding a note. The last choice applies
on the next loop downbeat. If transport stops first, the choice applies on
the next PLAY. The active key and pending choice are shown on the screen.

Frequency Lock uses the exact selected Hz for every pitched track, including
Bass. Track timing, envelopes, level and pan still shape the unison. Drums,
Nature, binaural, Sacred Bass, fixed reference and FX are suppressed while
locked. Reference Layer restores the ordinary arrangement. ENV still toggles
A4 tuning for Reference Layer.

On MIX, use EDIT to cycle the views. On Reset, turn K1 to arm and press SAVE to restore default mix settings. Auto Gain gently trims measured track levels. Auto Level applies role-specific balance and a lower peak ceiling. You can run both together.

Resonance displays reactive ribbons on PLAY. Select Original or Resonance under SETUP. After 10 seconds without navigation input, PLAY enters fullscreen. Musical keys continue to play in fullscreen. Turn a navigation control to return to PLAY.

The Lock Textures group can explicitly add drums and Nature to Frequency Lock.
This introduces other frequencies. Leave Extra Textures off for strict output.
On Nature, turn K3 right to audition for four seconds. Turn it left or press
HOME to exit. An intention change selects that intention's default Nature bed.

### New songs and sound palettes

From EVOLVE, press EDIT to open the song controls. Stop transport before
turning K1 right for **New Song**, or K2 right for **Reroll Sounds**. Reroll
keeps the motif and musical RNG state. SELECT chooses the track for K3's
sound lock, including the percussion kit on track 8. K4 locks Nature and FX
together. Turn a lock control left to unlock. Editing a Nature bed also locks
that selection so a deliberately disabled bed stays off. Sound locks travel
with the arrangement bank. PLAY and STOP preserve the current motif and
sounds. A stopped intention change draws a fresh palette for that intention.

### Navigation

ALGORITHM selects PLAY, SOUND, EVOLVE, MIX, DRUMS, and SETUP. HOME returns
to PLAY. ARP jumps to DRUMS without changing the drum enable setting. EDIT
cycles Pattern, Sound / Mix, and Mute / Solo. OCT+ is a DRUMS shortcut.
On SOUND, EDIT opens the category picker, SELECT chooses the category, and
EDIT opens it. SETUP groups lighting and visualizer controls with arrangement
banks on its second tab. OCT− jumps to banks. GLO opens Performance, with
K1 selecting the visual pacing policy. The displayed PLAY blit rate is a
software count and still needs confirmation on the physical LCD.

### Groove, MIX and experimental AIR

EVOLVE EDIT cycles Loop, New Song and Groove. On Groove, K1 chooses Intention,
Straight or Swing. K2 scales the timing offset from 0 to 100 percent. K3 is
loop length and K4 is Freeze. The timing profile applies to evolving piano, pluck, lead and harmony offbeats. Lead and harmony use smaller offsets with slow patches or at slow tempos. Frequency Lock uses straight timing. Bass, drums and downbeats stay on the transport clock.

MIX opens with musical channels and source buses together. Turn SELECT through the tracks and buses to change the focused controls. EDIT cycles All Channels, Master FX, Reset Mix, Active Channels and the taller Source Buses view. Use All Channels to recover muted or disabled sources. SEL and LFO mute and solo musical tracks. Bus controls retain their own routing. For example, Binaural keeps its stereo separation.

AIR is an opt-in experiment. K1 enables scanning, K2 selects a track or All,
K3 captures the first named compatible BLE MIDI advertiser as a reference,
and K4 holds or releases modulation. AIR uses coarse signal changes and
smooths its effect on the send. A single-track target needs an audible FX
return. No signal or switching AIR off returns modulation toward zero unless
Hold is active. The radio is off at startup. Real hand response and device
audio performance require hardware validation.

SOUND / Instrument shows a cached oscillator and attack/release preview. Brightness affects held notes. Attack and release apply to newly triggered notes. Set each control to zero to use the patch default. The four banks save these edits per track.

SETUP EDIT also opens Quick Find. K1 chooses a destination and K2 opens it.
Performance separates geometry time from UI draw time and reports average
Audio and FX times, callback percentiles, DMA XRUNs and active voices.

Each intention has Lead and Bass glide/vibrato defaults. Lock the relevant
track under EVOLVE / New Song to retain its manually selected motion when
changing intention. Saved arrangements recall their exact motion values.

MIX EDIT also offers Source Buses. SELECT chooses Nature, Sacred Bass,
Reference, Binaural, or FX, and the encoders adjust that bus's existing
controls. Meters show sampled post-routing signal activity. Binaural keeps
its stereo carrier routing and does not expose a pan control.
