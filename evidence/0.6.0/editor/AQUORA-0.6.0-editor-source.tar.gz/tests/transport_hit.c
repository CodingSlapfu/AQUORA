#include "serenity.h"
#include <assert.h>
#include <stdio.h>

static sr_engine a,b;
static int16_t pcm[512];

static void block(sr_engine *e){sr_render(e,pcm,256);}
static void silence(void)
{
    for(unsigned i=0;i<512;i++)assert(pcm[i]==0);
}

static void stopped_voices(void)
{
    sr_init(&a,731);
    a.play_grid=0; /* Exercise immediate input and the missed-release watchdog. */
    a.bed_level=0;
    a.reverb_amount=a.delay_amount=0;
    a.drums_enabled=0;
    sr_start(&a);
    a.tick_length=44100u*100;
    a.tick_phase=0;
    sr_key_down(&a,SR_BASS,4);
    unsigned count=a.note_ons;
    sr_key_down(&a,SR_LEAD,4);
    assert(a.note_ons==count);
    for(unsigned i=0;i<800;i++)block(&a);
    assert(a.sacred_gain>.001f);
    sr_key_up(&a,4);
    for(unsigned i=0;i<70;i++)block(&a);
    assert(a.sacred_gain<.00001f);
    sr_key_down(&a,SR_LEAD,1);
    for(unsigned i=0;i<1560;i++)block(&a);
    assert(a.watchdogs==1);
    for(unsigned i=0;i<SR_VOICES;i++)assert(!a.voices[i].gate);

    for(unsigned scene=0;scene<SR_SCENES;scene++){
        sr_set_scene(&a,scene);
        a.freeze=1;
        a.drums_enabled=1;
        a.binaural_enabled=1;
        a.bed_level=1;
        a.reverb_amount=.8f;
        a.delay_amount=.7f;
        a.tone_level=.1f;
        for(unsigned round=0;round<4;round++){
            sr_start(&a);
            for(unsigned key=0;key<27;key++)sr_key_down(&a,key%7,key);
            for(unsigned i=0;i<20;i++)block(&a);
            sr_stop(&a);
            block(&a);
            block(&a);silence();
            assert(!a.rev_history&&!a.delay_history);
            for(unsigned v=0;v<SR_VOICES;v++)assert(!a.voices[v].active);
            sr_start(&a);
            block(&a);
            for(unsigned v=0;v<SR_VOICES;v++)assert(!a.voices[v].key);
            sr_stop(&a);block(&a);
        }
    }
    puts("PASS duplicate held key, missed-release watchdog, Sacred Bass release, 32 saturated STOP/restart cycles, no stale FX or keyed voices");
}

/* Isolate the fixed oscillator from all generated tracks and effects. */
static unsigned rising_crossings(void)
{
    unsigned crossings=0;
    int16_t previous=0;
    for(unsigned i=0;i<SR_RATE/256;i++){
        block(&a);
        for(unsigned sample=0;sample<512;sample+=2){
            assert(pcm[sample]==pcm[sample+1]);
            crossings+=(previous<=0&&pcm[sample]>0);
            previous=pcm[sample];
        }
    }
    return crossings;
}

static void fixed_reference_isolation(void)
{
    sr_init(&a,731);
    sr_set_frequency(&a,4);
    a.bed_level=a.reverb_amount=a.delay_amount=0;
    a.sacred_mode=0;
    for(unsigned t=0;t<SR_TRACKS;t++)a.tracks[t].mute=1;
    sr_start(&a);
    assert(rising_crossings()==0);

    a.isolate=SR_ISOLATE_FIXED;
    a.tone_level=.10f;
    unsigned initial=rising_crossings();
    assert(initial>=526&&initial<=529);
    sr_set_scene(&a,6);
    a.bed_level=0;
    unsigned changed=rising_crossings();
    assert(changed>=526&&changed<=529);
    sr_stop(&a);
    block(&a);
    block(&a);silence();
    sr_start(&a);
    unsigned restarted=rising_crossings();
    assert(restarted>=526&&restarted<=529);

    a.tone_level=0;
    assert(rising_crossings()==0);
    silence();
    printf("PASS isolated fixed-reference crossings: %u initial, %u after scene change, %u after restart\n",
        initial,changed,restarted);
}

static void scene_frequency_isolation(void)
{
    static const unsigned expected[]={174,417,963,396,741,639,852,528,417,741,777,888,963};
    sr_init(&a,731);
    a.isolate=SR_ISOLATE_FIXED;
    a.tone_level=.07f;
    a.binaural_enabled=1;
    a.sacred_mode=2;
    sr_start(&a);
    for(unsigned scene=0;scene<SR_SCENES;scene++){
        sr_set_scene(&a,scene);
        unsigned crossings=rising_crossings();
        assert(crossings+2>=expected[scene]&&crossings<=expected[scene]+1);
    }
    a.isolate=SR_ISOLATE_SACRED;
    assert(rising_crossings()>=59);
    a.sacred_mode=0;
    for(unsigned b=0;b<80;b++)block(&a);
    silence();
    a.isolate=SR_ISOLATE_BINAURAL;
    block(&a);
    unsigned unequal=0;
    for(unsigned sample=0;sample<512;sample+=2)unequal+=pcm[sample]!=pcm[sample+1];
    assert(unequal>200);
    a.binaural_enabled=0;
    for(unsigned b=0;b<80;b++)block(&a);
    silence();
    sr_stop(&a);
    block(&a);
    block(&a);silence();
    puts("PASS all thirteen Auto frequencies in PCM, Sacred Bass isolation, independent binaural stereo and STOP silence");
}

static void loop_key_boundary(void)
{
    for(unsigned length=16;length<=64;length*=2){
        sr_init(&a,71);
        a.keyboard_mode=1;
        a.freeze=1;
        sr_set_loop_length(&a,length);
        sr_start(&a);
        a.tick_length=32;
        sr_render(&a,pcm,32);
        unsigned previous=sr_tonic(&a), voices=a.note_ons;
        sr_key_down(&a,SR_PIANO,1);
        sr_key_down(&a,SR_PIANO,5);
        assert(a.note_ons==voices&&a.pending_key==11&&sr_tonic(&a)==previous);
        for(unsigned step=1;step<length;step++){
            sr_render(&a,pcm,32);
            assert(sr_tonic(&a)==previous);
        }
        assert(!a.loop_pos);
        sr_set_loop_length(&a,32);
        sr_render(&a,pcm,32);
        assert(a.loop_length==32&&a.loop_pos==1&&sr_tonic(&a)==46&&!a.pending_key);
        assert(a.frequency==sr_scenes[a.scene].frequency);
        sr_stop(&a);
        block(&a);
        block(&a);
        silence();
    }
    puts("PASS next-loop tonic and length changes at all three loop lengths");
}

static void frequency_lock_pcm(void)
{
    for(unsigned scene=0;scene<SR_SCENES;scene++){
        sr_init(&a,721);
        sr_set_scene(&a,scene);
        sr_set_frequency_lock(&a,1);
        a.tone_level=.10f;
        a.sacred_mode=2;
        a.binaural_enabled=1;
        a.bed_level=1;
        a.reverb_amount=.8f;
        a.delay_amount=.7f;
        for(unsigned t=0;t<SR_TRACKS;t++)a.tracks[t].pan=0;
        sr_start(&a);
        a.tick_phase=0;
        a.tick_length=SR_RATE*2;
        a.motion[0].vibrato_depth=50;
        a.motion[1].glide_mode=2;
        for(unsigned t=0;t<SR_DRUMS;t++)sr_key_down(&a,t,t);
        unsigned expected=(unsigned)sr_frequencies[a.frequency].hz;
        unsigned actual=rising_crossings();
        assert(actual+2>=expected&&actual<=expected+1);
        for(unsigned t=0;t<SR_TRACKS;t++)a.tracks[t].mute=1;
        block(&a);
        silence();
        assert(!a.rev_history&&!a.delay_history);
        sr_set_frequency_lock(&a,0);
        block(&a);
        assert(!a.frequency_lock&&a.running);
        for(unsigned v=0;v<SR_VOICES;v++)assert(!a.voices[v].active);
    }
    puts("PASS strict Frequency Lock PCM in thirteen scenes, suppression of textures, and clean mode exit");
}

static unsigned nature_pcm_peak(unsigned type,float level)
{
    unsigned peak=0;
    sr_init(&a,4321);
    sr_start(&a);
    a.isolate=SR_ISOLATE_NATURE;
    a.bed_type=type;
    a.bed_level=level;
    for(unsigned n=0;n<900;n++){
        block(&a);
        for(unsigned i=0;i<512;i++){
            int v=pcm[i];
            unsigned mag=v<0?-v:v;
            if(mag>peak)peak=mag;
        }
    }
    return peak;
}

static void nature_audibility(void)
{
    for(unsigned type=1;type<=7;type++){
        unsigned low=nature_pcm_peak(type,.18f);
        unsigned middle=nature_pcm_peak(type,.5f);
        unsigned high=nature_pcm_peak(type,1.f);
        assert(low>30&&middle>low&&high>middle&&high<12000);
        assert(nature_pcm_peak(type,0)==0);
        printf("Nature %u peak at 18/50/100%%: %u/%u/%u\n",type,low,middle,high);
    }
    a.solo=SR_LEAD;
    a.nature_audition=512;
    block(&a);
    assert(a.nature_audition==256&&a.solo==SR_LEAD);
    block(&a);
    assert(!a.nature_audition&&a.solo==SR_LEAD);
    block(&a);silence();
}

static void multi_bar_percussion(void)
{
    for(unsigned length=16;length<=64;length*=2){
        sr_init(&a,441);
        sr_set_loop_length(&a,length);
        a.drum_hit=100;
        a.drum_density=2;
        a.freeze=1;
        sr_start(&a);
        a.tick_length=64;
        unsigned masks[4]={0};
        for(unsigned step=0;step<length*2;step++){
            unsigned before=a.tracks[SR_DRUMS].events;
            sr_render(&a,pcm,64);
            unsigned bar=(step%length)/16;
            unsigned hit=a.tracks[SR_DRUMS].events>before;
            if(step<length)masks[bar]|=hit<<(step%16);
            else assert(hit==((masks[bar]>>(step%16))&1u));
        }
        for(unsigned bar=0;bar<length/16;bar++){
            assert(masks[bar]&1u);
            for(unsigned prev=0;prev<bar;prev++)assert(masks[bar]!=masks[prev]);
        }
    }
    puts("PASS 16/32/64 percussion, distinct answer bars at HIT 100 and repeatable loop timing");
}

static void vibrato_pcm(void)
{
    int16_t clean[512];
    for(unsigned track=SR_LEAD;track<=SR_BASS;track++){
        sr_init(&a,231);
        sr_init(&b,231);
        a.bed_level=b.bed_level=0;
        a.reverb_amount=b.reverb_amount=a.delay_amount=b.delay_amount=0;
        a.sacred_mode=b.sacred_mode=0;
        sr_start(&a);sr_start(&b);
        a.tick_phase=b.tick_phase=0;
        b.motion[track].vibrato_depth=35;
        sr_key_down(&a,track,8);sr_key_down(&b,track,8);
        for(unsigned i=0;i<12;i++){block(&a);block(&b);}
        block(&a);
        for(unsigned i=0;i<512;i++)clean[i]=pcm[i];
        block(&b);
        unsigned different=0;
        for(unsigned i=0;i<512;i++)different+=clean[i]!=pcm[i];
        assert(different>100);
    }
    puts("PASS Lead and Bass vibrato each change rendered PCM independently of glide");
}

static void hit_cap(void)
{
    sr_init(&a,3131);
    sr_init(&b,3131);
    sr_start(&a);sr_start(&b);
    a.drum_density=b.drum_density=2;
    a.drum_hit=SR_HIT_MAX;b.drum_hit=255;
    a.tick_length=b.tick_length=32;
    for(unsigned i=0;i<3500;i++){
        block(&a);block(&b);
        assert(a.optional_hits==b.optional_hits);
    }
    unsigned eligible=a.sequence_step/4;
    assert(a.optional_hits==eligible);
    printf("PASS 100%% equals corrupted 255%% input: %u optional strikes in %u eligible subdivisions\n",a.optional_hits,eligible);
    sr_init(&a,1);sr_start(&a);a.drum_hit=0;a.tick_length=32;
    for(unsigned i=0;i<500;i++)block(&a);
    assert(!a.optional_hits&&a.tracks[SR_DRUMS].events>0&&a.drums_enabled);
    for(unsigned scene=0;scene<SR_SCENES;scene++){
        sr_init(&a,901);sr_set_scene(&a,scene);sr_start(&a);
        float peak=0;
        for(unsigned i=0;i<760;i++){
            block(&a);
            if(a.tracks[SR_DRUMS].meter>peak)peak=a.tracks[SR_DRUMS].meter;
        }
        assert(a.tracks[SR_DRUMS].events>0&&peak>.07f);
        printf("Scene %u drum peak %.3f, %u strikes\n",scene,peak,a.tracks[SR_DRUMS].events);
    }
    puts("PASS HIT zero retains pulse and all thirteen scenes produce audible-range drum PCM");
}
int main(void){stopped_voices();fixed_reference_isolation();scene_frequency_isolation();loop_key_boundary();frequency_lock_pcm();nature_audibility();multi_bar_percussion();vibrato_pcm();hit_cap();return 0;}
